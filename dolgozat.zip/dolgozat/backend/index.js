const express = require('express');
const mysql = require('mysql');

//port, localhost
let port = 3000;
let host = 'localhost';

const app = express();
app.use(express.json());
//adatbazis neve
const connection = mysql.createConnection({
    host: host,
    user: 'root',
    password: '',
    database: 'taxi,',
});

//fuvarok get
app.get('/fuvarok', (req, res) => {
    connection.query('SELECT id, DATE_FORMAT(indulas_idopontja,"%Y-%m-%d") utazas_tartma , megtett_tavolsag, viteldij, borravalo, fizetes_modja', (err, results) => {
        if (err) {
            console.log(err);
            res.send("HIBA");
        } else {
            console.log(result);
            res.send(results);
        }
    });
});
//fuvarok kilistazasas
app.get('/fuvarok', (req, res) => {
    connection.query('SELECT * FROM fuvarok', (err, results) => {

        if (err) {
            console.log(err);
            res.send("HIBA");
        } else {
            console.log(result);
            res.send(results);
        }
    });
});
//app.del
app.delete('fuvarok', (req, res) => {
    connection.query('SELECT id', (err, results) => {
        if (err) {
            console.log(err);
            res.send("HIBA");
        } else {
            console.log(results);
            res.send(results);
        }
    })
})

app.listen(port, host, () => {
    console.log(`ITT FUT A SZERVER: http://${host}:${port}`);
})